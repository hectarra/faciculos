<?php
/**
 * Manejador de pedidos para el plugin ACF + Woo Subscriptions Fascículos
 *
 * @package ACF_Woo_Fasciculos
 * @since 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Clase para manejar toda la funcionalidad relacionada con pedidos
 */
class ACF_Woo_Fasciculos_Orders {

    /**
     * Constructor
     */
    public function __construct() {
        // Inicializar cualquier configuración necesaria
    }

    /**
     * Guardar el plan de fascículos en un item del pedido
     *
     * @param WC_Order_Item_Product $item Item del pedido.
     * @param string                $cart_item_key Clave del item del carrito.
     * @param array                 $values Valores del item del carrito.
     * @param WC_Order              $order Pedido.
     * @return void
     */
    public function save_plan_to_order_item( $item, $cart_item_key, $values, $order ) {
        if ( isset( $values[ ACF_Woo_Fasciculos::META_PLAN_CACHE ] ) ) {
            $item->add_meta_data( ACF_Woo_Fasciculos::META_PLAN_CACHE, wp_json_encode( $values[ ACF_Woo_Fasciculos::META_PLAN_CACHE ] ), false );
        }
        if ( isset( $values[ ACF_Woo_Fasciculos::META_ACTIVE_INDEX ] ) ) {
            $item->add_meta_data( ACF_Woo_Fasciculos::META_ACTIVE_INDEX, intval( $values[ ACF_Woo_Fasciculos::META_ACTIVE_INDEX ] ), false );
        }
    }

    /**
     * Copiar el plan de fascículos a la suscripción
     *
     * @param WC_Subscription $subscription Suscripción creada.
     * @param WC_Order        $order Pedido original.
     * @param mixed           $recurring_cart Carrito recurrente.
     * @return void
     */
    public function copy_plan_to_subscription( $subscription, $order, $recurring_cart = null ) {
        if ( ! ACF_Woo_Fasciculos_Utils::is_valid_subscription( $subscription ) || ! $subscription->get_id() || ! ACF_Woo_Fasciculos_Utils::is_valid_order( $order ) ) {
            return;
        }
        $plan_copied = false;
        foreach ( $order->get_items() as $order_item ) {
            $plan_json = $order_item->get_meta( ACF_Woo_Fasciculos::META_PLAN_CACHE );
            if ( $plan_json ) {
                $subscription->update_meta_data( ACF_Woo_Fasciculos::META_PLAN_CACHE, $plan_json );
                $plan_copied = true;
            }
            $index = $order_item->get_meta( ACF_Woo_Fasciculos::META_ACTIVE_INDEX );
            $subscription->update_meta_data( ACF_Woo_Fasciculos::META_ACTIVE_INDEX, ( '' !== $index && null !== $index ) ? intval( $index ) : 0 );
        }
        if ( $plan_copied ) {
            $subscription->save();
        }
    }

    /**
     * Manejar la creación de un pedido de renovación
     *
     * @param WC_Order        $renewal_order Pedido de renovación.
     * @param WC_Subscription $subscription Suscripción relacionada.
     * @return void
     */
    public function on_renewal_order_created( $renewal_order, $subscription ) {
        if ( ! ACF_Woo_Fasciculos_Utils::is_valid_order( $renewal_order ) || ! ACF_Woo_Fasciculos_Utils::is_valid_subscription( $subscription ) ) {
            return;
        }
    
        $plan = $this->get_subscription_plan( $subscription );
        if ( empty( $plan ) ) {
            return;
        }
    
        $active = $this->get_active_index( $subscription );
        $row = ACF_Woo_Fasciculos_Utils::get_plan_row( $plan, $active );
        if ( ! $row ) {
            return;
        }
    
        $main_product_from_subscription = null;
        foreach ($subscription->get_items() as $item) {
            $product = $item->get_product();
            if ($product) {
                $main_product_from_subscription = $product;
                break;
            }
        }
    
        if ( $main_product_from_subscription && class_exists('WC_Product_Bundle') && $main_product_from_subscription->is_type('bundle') ) {
            $bundled_items = $main_product_from_subscription->get_bundled_items();
            if ( ! empty( $bundled_items ) ) {
                foreach ( $bundled_items as $bundled_item ) {
                    $bundled_product = $bundled_item->get_product();
                    if ( $bundled_product ) {
                        $item_id = $renewal_order->add_product( $bundled_product, $bundled_item->get_quantity() );
                        if ( $item_id ) {
                            $new_item = $renewal_order->get_item( $item_id );
                            if ( $new_item ) {
                                $new_item->set_subtotal(0);
                                $new_item->set_total(0);
                                $new_item->add_meta_data('_bundled_by_subscription', $subscription->get_id(), true);
                                $new_item->save();
                            }
                        }
                    }
                }
                $renewal_order->add_order_note(__('Productos del bundle añadidos a la orden para la gestión de stock.', 'acf-woo-fasciculos'));
            }
        }
    
        foreach ( $renewal_order->get_items() as $item_id => $item ) {
            if ( ! $item instanceof WC_Order_Item_Product ) {
                continue;
            }
            if ( $main_product_from_subscription && $item->get_product_id() === $main_product_from_subscription->get_id() ) {
                $item->delete_meta_data( ACF_Woo_Fasciculos::META_ACTIVE_INDEX );
                $item->delete_meta_data( ACF_Woo_Fasciculos::META_PLAN_CACHE );
                $item->add_meta_data( ACF_Woo_Fasciculos::META_ACTIVE_INDEX, $active, true );
                $item->add_meta_data( ACF_Woo_Fasciculos::META_PLAN_CACHE, wp_json_encode( $plan ), true );
                $item->save();
            }
        }
    
        $renewal_order->calculate_totals();
        $renewal_order->save();
    
        $product_name = ACF_Woo_Fasciculos_Utils::get_product_name( $row['product_id'] );
        $renewal_order->add_order_note( sprintf(
            __( '📦 Fascículo semana %1$d/%2$d: %3$s — %4$s', 'acf-woo-fasciculos' ),
            $active + 1,
            count( $plan ),
            $product_name,
            ACF_Woo_Fasciculos_Utils::format_price( $row['price'] )
        ) );
    }

    /**
     * Actualizar metadatos de items en pedido de renovación
     *
     * @param WC_Order        $renewal_order Pedido de renovación.
     * @param WC_Subscription $subscription Suscripción relacionada.
     * @return void
     */
    public function update_renewal_order_items_meta( $renewal_order, $subscription ) {
        if ( ! ACF_Woo_Fasciculos_Utils::is_valid_order( $renewal_order ) || ! ACF_Woo_Fasciculos_Utils::is_valid_subscription( $subscription ) ) {
            return;
        }
        $plan = $this->get_subscription_plan( $subscription );
        if ( empty( $plan ) ) {
            return;
        }
        $active_index = $this->get_active_index( $subscription );
        foreach ( $renewal_order->get_items() as $item ) {
            if ( $item instanceof WC_Order_Item_Product ) {
                $item->update_meta_data( ACF_Woo_Fasciculos::META_ACTIVE_INDEX, $active_index );
                $item->update_meta_data( ACF_Woo_Fasciculos::META_PLAN_CACHE, wp_json_encode( $plan ) );
                $item->save();
            }
        }
        $renewal_order->save();
    }

    /**
     * Manejar cambios de estado en pedidos de renovación
     *
     * @param int    $order_id ID del pedido.
     * @param string $old_status Estado anterior.
     * @param string $new_status Nuevo estado.
     * @param WC_Order $order Objeto del pedido.
     * @return void
     */
    public function on_order_status_progresses_renewal( $order_id, $old_status, $new_status, $order ) {
        if ( ! in_array( $new_status, array( 'processing', 'completed' ), true ) ) {
            return;
        }
        if ( ! $order instanceof WC_Order ) {
            $order = wc_get_order( $order_id );
        }
        if ( ! $order || ! ACF_Woo_Fasciculos_Utils::is_renewal_order( $order ) ) {
            return;
        }
        if ( class_exists( 'WC_Product_Bundle' ) ) {
            if ( ! $this->manage_bundle_stock_for_renewal( $order ) ) {
                return;
            }
        }
        $subscriptions = ACF_Woo_Fasciculos_Utils::get_renewal_subscriptions( $order_id );
        foreach ( $subscriptions as $subscription ) {
            $this->process_renewal_completion( $subscription, $order_id, $new_status );
        }
    }

    /**
     * Procesar la finalización de una renovación
     *
     * @param WC_Subscription $subscription Suscripción.
     * @param int             $order_id ID del pedido de renovación.
     * @param string          $new_status Nuevo estado del pedido.
     * @return void
     */
    private function process_renewal_completion( $subscription, $order_id, $new_status ) {
        if ( ! ACF_Woo_Fasciculos_Utils::is_valid_subscription( $subscription ) || ACF_Woo_Fasciculos_Utils::is_order_processed( $subscription, $order_id ) ) {
            return;
        }
        $plan = $this->get_subscription_plan( $subscription );
        if ( empty( $plan ) ) {
            return;
        }
        $current_active = $this->get_active_index( $subscription );
        $next_index = $current_active + 1;
        $next_row = ACF_Woo_Fasciculos_Utils::get_plan_row( $plan, $next_index );
        if ( $next_row ) {
            $this->advance_to_next_week( $subscription, $next_index, $next_row, $plan, $order_id, $new_status, $current_active );
        } else {
            $this->complete_subscription_plan( $subscription, $order_id );
        }
    }

    /**
     * Avanzar a la siguiente semana
     *
     * @param WC_Subscription $subscription Suscripción.
     * @param int             $next_index Índice de la siguiente semana.
     * @param array           $next_row Datos de la siguiente semana.
     * @param array           $plan Plan completo.
     * @param int             $order_id ID del pedido.
     * @param string          $new_status Nuevo estado del pedido.
     * @param int             $current_active Índice actual.
     * @return void
     */
    private function advance_to_next_week( $subscription, $next_index, $next_row, $plan, $order_id, $new_status, $current_active ) {
        $this->update_subscription_recurring_total( $subscription, $next_index, $plan );
        $subscription->update_meta_data( ACF_Woo_Fasciculos::META_ACTIVE_INDEX, $next_index );
        $this->add_renewal_completion_note( $subscription, $order_id, $new_status, $current_active, $next_index, $plan );
        ACF_Woo_Fasciculos_Utils::mark_order_as_processed( $subscription, $order_id );
        $subscription->save();
    }

    /**
     * Completar el plan de suscripción
     *
     * @param WC_Subscription $subscription Suscripción.
     * @param int             $order_id ID del pedido.
     * @return void
     */
    private function complete_subscription_plan( $subscription, $order_id ) {
        $subscription->add_order_note( __( '🎉 Plan de fascículos completado. La suscripción se cancelará.', 'acf-woo-fasciculos' ) );
        ACF_Woo_Fasciculos_Utils::mark_order_as_processed( $subscription, $order_id );
        $subscription->save();
        $subscription->update_status( 'cancelled', __( 'Plan completado.', 'acf-woo-fasciculos' ) );
    }

    /**
     * Agregar nota de finalización de renovación
     *
     * @param WC_Subscription $subscription Suscripción.
     * @param int             $order_id ID del pedido.
     * @param string          $new_status Nuevo estado.
     * @param int             $current_active Índice actual.
     * @param int             $next_index Índice siguiente.
     * @param array           $plan Plan de fascículos.
     * @return void
     */
    private function add_renewal_completion_note( $subscription, $order_id, $new_status, $current_active, $next_index, $plan ) {
        $current_week = $current_active + 1;
        $total_weeks = count( $plan );
        $message = ( $next_index >= $total_weeks )
            ? sprintf( __( '📦 Última semana completada: %1$d/%2$d.', 'acf-woo-fasciculos' ), $current_week, $total_weeks )
            : sprintf( __( '📦 Semana %1$d/%2$d completada. Preparando semana %3$d.', 'acf-woo-fasciculos' ), $current_week, $total_weeks, $next_index + 1 );
        $subscription->add_order_note( $message );
        $order = wc_get_order( $order_id );
        if ( $order ) {
            $order->add_order_note( $message );
        }
    }

    /**
     * Actualizar el total recurrente de la suscripción
     *
     * @param WC_Subscription $subscription Suscripción.
     * @param int             $week_index Índice de la semana.
     * @param array           $plan Plan de fascículos.
     * @return void
     */
    private function update_subscription_recurring_total( $subscription, $week_index, $plan ) {
        $row = ACF_Woo_Fasciculos_Utils::get_plan_row( $plan, $week_index );
        if ( ! $row ) return;
        $new_product = wc_get_product( intval( $row['product_id'] ) );
        if ( ! $new_product ) return;
        $new_price = floatval( $row['price'] );
        foreach ( $subscription->get_items() as $item ) {
            if ( $item instanceof WC_Order_Item_Product ) {
                $qty = max( 1, intval( $item->get_quantity() ) );
                $item->set_product( $new_product );
                $item->set_name( $new_product->get_name() );
                $item->set_product_id( $new_product->get_id() );
                $item->set_subtotal( $new_price * $qty );
                $item->set_total( $new_price * $qty );
                $item->save();
            }
        }
        $subscription->calculate_totals();
        $subscription->save();
    }

    /**
     * Obtener el plan de fascículos de una suscripción
     *
     * @param WC_Subscription $subscription Suscripción.
     * @return array Plan de fascículos.
     */
    private function get_subscription_plan( $subscription ) {
        $plan_json = $subscription->get_meta( ACF_Woo_Fasciculos::META_PLAN_CACHE );
        if ( ! $plan_json ) return array();
        $plan = json_decode( $plan_json, true );
        return is_array( $plan ) ? $plan : array();
    }

    /**
     * Obtener el índice activo de una suscripción
     *
     * @param WC_Subscription $subscription Suscripción.
     * @return int Índice activo.
     */
    private function get_active_index( $subscription ) {
        $index = $subscription->get_meta( ACF_Woo_Fasciculos::META_ACTIVE_INDEX );
        return ( '' !== $index && null !== $index ) ? intval( $index ) : 0;
    }

    /**
     * Obtener información de un pedido relacionado con fascículos
     *
     * @param WC_Order $order Pedido.
     * @return array Información del pedido.
     */
    public function get_order_fasciculos_info( $order ) {
        if ( ! ACF_Woo_Fasciculos_Utils::is_valid_order( $order ) ) return array();
        $fasciculos_items = array();
        foreach ( $order->get_items() as $item_id => $item ) {
            if ( $item->get_meta( ACF_Woo_Fasciculos::META_PLAN_CACHE ) ) {
                $active_index = $item->get_meta( ACF_Woo_Fasciculos::META_ACTIVE_INDEX );
                $fasciculos_items[] = array(
                    'item_id' => $item_id,
                    'active_index' => ( '' !== $active_index && null !== $active_index ) ? intval( $active_index ) : 0,
                    'plan' => json_decode( $item->get_meta( ACF_Woo_Fasciculos::META_PLAN_CACHE ), true ),
                );
            }
        }
        return array(
            'has_fasciculos' => ! empty( $fasciculos_items ),
            'items' => $fasciculos_items,
            'total_items' => count( $fasciculos_items ),
        );
    }
    
    /**
     * Verifica el stock de TODOS los productos en un pedido de renovación.
     *
     * @param WC_Order $order El pedido de renovación.
     * @return bool True si el stock es suficiente, false en caso contrario.
     */
    private function manage_bundle_stock_for_renewal( $order ) {
        foreach ( $order->get_items() as $item ) {
            if ( ! $item instanceof WC_Order_Item_Product ) continue;
            $product = $item->get_product();
            $quantity_needed = $item->get_quantity();
            if ( ! $product || ! $product->managing_stock() || $quantity_needed <= 0 ) continue;
            if ( ! $product->has_enough_stock( $quantity_needed ) ) {
                $order->update_status( 'on-hold', sprintf(
                    __( 'Pedido en espera por falta de stock para: %s.', 'acf-woo-fasciculos' ),
                    $product->get_name()
                ) );
                return false;
            }
        }
        $order->add_order_note( __( '✅ Verificación de stock para todos los productos completada.', 'acf-woo-fasciculos' ) );
        return true;
    }
}