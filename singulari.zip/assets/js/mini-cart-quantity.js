/**
 * Mini-cart quantity controls for Elementor cart widget
 *
 * Adds +/- buttons to change product quantities directly in the mini-cart.
 *
 * @package ACF_Woo_Fasciculos
 * @since 3.7.0
 */
(function ($) {
    "use strict";

    var MiniCartQty = {
        /**
         * Initialize event delegation on the mini-cart container.
         */
        init: function () {
            $(document.body).on(
                "click",
                ".acf-mini-cart-qty-btn",
                this.onButtonClick.bind(this)
            );
        },

        /**
         * Handle +/- button click: send AJAX to update quantity.
         *
         * @param {Event} e Click event.
         */
        onButtonClick: function (e) {
            e.preventDefault();
            e.stopPropagation();

            var $btn = $(e.currentTarget);
            var $wrapper = $btn.closest(".acf-mini-cart-qty");
            var $qty = $wrapper.find(".acf-mini-cart-qty-value");
            var cartItemKey = $wrapper.data("cart-key");
            var currentQty = parseInt($qty.text(), 10) || 1;
            var isPlus = $btn.hasClass("acf-mini-cart-qty-plus");
            var newQty = isPlus ? currentQty + 1 : currentQty - 1;

            // Minimum quantity is 0 (0 = remove item).
            if (newQty < 0) {
                return;
            }

            // Disable buttons while processing.
            $wrapper.addClass("acf-updating");
            $qty.text(newQty);

            $.ajax({
                type: "POST",
                url: acf_mini_cart_params.ajax_url,
                data: {
                    action: "acf_update_mini_cart_qty",
                    cart_item_key: cartItemKey,
                    quantity: newQty,
                    nonce: acf_mini_cart_params.nonce,
                },
                success: function (response) {
                    if (response.success) {
                        // Trigger WooCommerce cart fragments refresh.
                        $(document.body).trigger("wc_fragment_refresh");
                        $(document.body).trigger("updated_wc_div");
                    }
                },
                complete: function () {
                    $wrapper.removeClass("acf-updating");
                },
            });
        },
    };

    $(function () {
        MiniCartQty.init();
    });
})(jQuery);
